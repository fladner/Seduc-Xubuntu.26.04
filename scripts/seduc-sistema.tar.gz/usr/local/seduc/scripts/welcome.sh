#!/usr/bin/env bash

# Sem "set -e": em script de interface um erro não pode fechar a janela sem aviso.
set -uo pipefail

SCRIPT_VERSION="1.7-6"

#####################
## VARIABLE GLOBAL ##
#####################
LOG="/usr/local/seduc/logs/welcome.log"
FLAG="/usr/local/seduc/flags/pos-install"
CRIAR_USUARIOS="/usr/local/seduc/scripts/criar_usuarios.sh"

# Usuários disponíveis: login|Nome exibido|Grupo
# O login também é a senha padrão. Mantenha em sincronia com criar_usuarios.sh
USUARIOS=(
    "aluno|Aluno|Laboratório"
    "direcao|Direção|Núcleo gestor"
    "coordenacao|Coordenação|Núcleo gestor"
    "secretaria|Secretaria|Núcleo gestor"
    "financeiro|Financeiro|Núcleo gestor"
    "professores|Professores|Apoio"
    "multimeios|Multimeios|Apoio"
    "aee|AEE|Apoio"
    "gremio|Grêmio|Apoio"
)

# O administrador que marcou "Não mostrar mais ao entrar": a tela não abre mais no
# login dele (pela Central do Suporte continua abrindo)
OCULTA="${XDG_CONFIG_HOME:-$HOME/.config}/seduc/boas-vindas-oculta"

AMBIENTES="/usr/local/seduc/ambientes.conf"
IDENTIFICACAO="/usr/local/seduc/identificacao.conf"
API_INEP="https://api.simet.nic.br/educacao-conectada/inep-service/school-by-inep"

# --inep <código>: nome da escola pela API do Medidor Educação Conectada (NIC.br), como
# na primeira versão do welcome. Uma linha: ESCOLA|<nome> | NAOENCONTRADA | INVALIDO | SEMREDE
if [ "${1:-}" = "--inep" ]; then
    INEP=$(printf '%s' "${2:-}" | tr -cd '0-9')
    [ ${#INEP} -eq 8 ] || { echo "INVALIDO"; exit 0; }
    if ! DADOS=$(curl -sSf -L -m 20 --retry 2 --retry-max-time 40 \
        -d "INEP_CODE=$INEP" "$API_INEP" 2>/dev/null); then
        echo "SEMREDE"; exit 0
    fi
    NOME=$(printf '%s' "$DADOS" | tr -d '\r|' | head -1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | cut -c1-150)
    case "${NOME,,}" in
        ""|unknown|null) echo "NAOENCONTRADA" ;;
        *) echo "ESCOLA|$NOME" ;;
    esac
    exit 0
fi

# --ocultar / --mostrar: liga e desliga a abertura no login (Central do Suporte em web)
case "${1:-}" in
    --ocultar) mkdir -p "$(dirname "$OCULTA")" && date '+%F %T' > "$OCULTA"; exit $? ;;
    --mostrar) rm -f "$OCULTA"; exit $? ;;
esac

# --listar: para a Central do Suporte em web (antes do log, que toma a saída padrão).
# Uma linha por informação, separada por "|":
#   LIVE | ERRO|<texto> | SISTEMA|<nome> | USUARIO|<login>|<nome>|<grupo>|<1 se já existe>
#   AMBIENTE|<escola|crede>|<sigla>|<nome> | IDENT|<tipo>|<INEP>|<CREDE>|<ambiente>|<escola>|<computador>
#   OCULTA (o administrador marcou "Não mostrar mais ao entrar")
if [ "${1:-}" = "--listar" ]; then
    grep -q "casper" /proc/cmdline && echo "LIVE"
    [ -f "$OCULTA" ] && echo "OCULTA"
    if ! id -nG | tr ' ' '\n' | grep -qx sudo; then
        echo "ERRO|Só o administrador local do computador (grupo sudo) cria os usuários."
        exit 0
    fi
    echo "SISTEMA|Xubuntu 26.04 LTS"
    for ITEM in "${USUARIOS[@]}"; do
        IFS="|" read -r LOGIN NOME GRUPO <<< "$ITEM"
        id -u "$LOGIN" >/dev/null 2>&1 && EXISTE=1 || EXISTE=0
        echo "USUARIO|$LOGIN|$NOME|$GRUPO|$EXISTE"
    done
    [ -r "$AMBIENTES" ] && grep -v '^[[:space:]]*#' "$AMBIENTES" | grep '|' | sed 's/^/AMBIENTE|/'
    if [ -r "$IDENTIFICACAO" ]; then
        ( . "$IDENTIFICACAO" 2>/dev/null
          echo "IDENT|${TIPO:-}|${INEP:-}|${CREDE:-}|${AMBIENTE:-}|${ESCOLA:-}|${COMPUTADOR:-}" )
    fi
    exit 0
fi

#########
## LOG ##
#########
mkdir -p "$(dirname "$LOG")" 2>/dev/null
if [ ! -w "$(dirname "$LOG")" ]; then
    LOG="${XDG_CACHE_HOME:-$HOME/.cache}/seduc-welcome.log"
    mkdir -p "$(dirname "$LOG")"
fi
[ -f "$LOG" ] && mv -f "$LOG" "$LOG.bak"
exec >"$LOG" 2>&1

echo "===== INÍCIO $(date) - versão $SCRIPT_VERSION ====="

###############
## FUNCTIONS ##
###############

# Verifica se está rodando em ambiente Live
check_live() {
    if grep -q "casper" /proc/cmdline; then
        echo "Ambiente Live detectado. Saindo..."
        exit 0
    fi
}

# Verifica se a flag de pós-instalação existe
check_flag() {
    if [ -f "$FLAG" ]; then
        echo "Pós-instalação já executada. Saindo..."
        exit 0
    fi
}

# O administrador marcou "Não mostrar mais ao entrar"
check_oculta() {
    if [ -f "$OCULTA" ]; then
        echo "Boas-vindas oculta por este administrador ($OCULTA). Saindo..."
        exit 0
    fi
}

# Só o administrador (grupo sudo) configura o computador
check_admin() {
    if ! id -nG | tr ' ' '\n' | grep -qx sudo; then
        echo "Usuário $(id -un) não é administrador. Saindo..."
        exit 0
    fi
}

# Tela de boas-vindas ao administrador
show_welcome() {
    yad --title="Bem-vindo" \
        --width=480 --height=300 \
        --center \
        --borders=10 \
        --window-icon=help-about \
        --image=seduc-logo \
        --text="<b>Bem-vindo(a), administrador(a)!</b>

Este é o Linux da Secretaria de Educação - SEDUC, baseado no <b>Xubuntu 26.04 LTS</b>.

Agora vamos preparar este computador para uso: na próxima tela você escolhe quais usuários serão criados nele.

Clique em <b>Avançar</b> para continuar." \
        --button="Não mostrar mais:2" --button="Sair:1" --button="Avançar:0"
    local R=$?
    if [ "$R" -eq 2 ]; then
        mkdir -p "$(dirname "$OCULTA")" && date '+%F %T' > "$OCULTA"
        echo "Administrador escolheu não mostrar mais ao entrar"
        yad --info --title="Boas-vindas" --center --borders=10 --button="OK:0" \
            --text="A tela de boas-vindas não vai mais abrir quando você entrar.\n\nPara criar os usuários depois, use a Central do Suporte > Boas-vindas e usuários."
        return 1
    fi
    return "$R"
}

# Lista os usuários e devolve os logins marcados, um por linha
select_usuarios() {
    local LINHAS=() ITEM LOGIN NOME GRUPO

    for ITEM in "${USUARIOS[@]}"; do
        IFS="|" read -r LOGIN NOME GRUPO <<< "$ITEM"
        LINHAS+=(FALSE "$NOME" "$GRUPO" "$LOGIN" "$LOGIN")
    done

    yad --list --checklist \
        --title="Usuários do computador" \
        --width=520 --height=440 \
        --center \
        --borders=10 \
        --window-icon=system-users \
        --text="Marque os usuários que devem ser criados neste computador.\n\nO <b>primeiro usuário marcado</b> define o nome do computador e o tema." \
        --column="Criar:CHK" --column="Usuário" --column="Grupo" \
        --column="Login" --column="Senha padrão" \
        --print-column=4 --separator="" \
        --button="Voltar:1" --button="Avançar:0" \
        "${LINHAS[@]}"
}

# Confirma a lista e as senhas antes de aplicar
confirm_usuarios() {
    local TEXTO="" LOGIN

    for LOGIN in "$@"; do
        TEXTO+=" • Usuário <b>$LOGIN</b>, senha <b>$LOGIN</b>\n"
    done

    yad --question \
        --title="Confirmar usuários" \
        --width=450 \
        --center \
        --borders=10 \
        --text="Serão criados os usuários:\n\n${TEXTO}\nRecomenda-se alterar as senhas após o primeiro login.\nA senha do administrador será solicitada a seguir." \
        --button="Voltar:1" --button="Criar usuários:0"
}

# Cria os usuários como root, com barra de progresso
setup_usuarios() {
    local STATUS_FILE STATUS

    STATUS_FILE=$(mktemp)
    echo 1 > "$STATUS_FILE"

    (
        echo "# Criando usuários e configurando o computador..."
        # A saída vai para o log do próprio script, nunca para o yad
        pkexec "$CRIAR_USUARIOS" "$@" >/dev/null 2>&1
        echo $? > "$STATUS_FILE"
        echo "100"
    ) | yad --progress \
        --title="Configurando o computador" \
        --text="Aguarde enquanto o sistema é configurado..." \
        --center \
        --pulsate \
        --no-cancel \
        --auto-close \
        --width=400

    STATUS=$(cat "$STATUS_FILE")
    rm -f "$STATUS_FILE"
    echo "criar_usuarios.sh terminou com código $STATUS"

    return "$STATUS"
}

# Oferece reiniciar para aplicar nome do computador e tema
finish() {
    yad --question \
        --title="Configuração concluída" \
        --width=420 \
        --center \
        --borders=10 \
        --text="Configuração concluída com sucesso!\n\nReinicie o computador para aplicar o nome do computador e o tema." \
        --button="Depois:1" --button="Reiniciar agora:0" \
        && systemctl reboot
}

##########
## MAIN ##
##########
# --central: aberto pela Central do Suporte, roda mesmo depois da pós-instalação
CENTRAL=0
[ "${1:-}" = "--central" ] && CENTRAL=1

check_live
(( CENTRAL )) || check_flag
(( CENTRAL )) || check_oculta
if (( CENTRAL )) && ! id -nG | tr ' ' '\n' | grep -qx sudo; then
    yad --info --title="Boas-vindas e usuários" --center --borders=10 --button="OK:0" \
        --text="Só o administrador local do computador (grupo sudo) cria os usuários."
    exit 0
fi
check_admin
# Com a Central do Suporte em web instalada, o primeiro login abre direto a página
# Boas-vindas dela (com a identificação do computador), não a tela inicial da Central;
# como o welcome em yad, volta a cada login do administrador até criar os usuários.
if (( ! CENTRAL )) && command -v central-suporte >/dev/null 2>&1; then
    echo "Abrindo a Central do Suporte em web (boas-vindas)"
    exec central-suporte --abrir boas-vindas
fi
show_welcome || exit 0

while true; do
    # Voltar/fechar na lista retorna à boas-vindas
    if ! SAIDA=$(select_usuarios); then
        show_welcome || exit 0
        continue
    fi

    mapfile -t SELECIONADOS < <(printf '%s\n' "$SAIDA" | tr -d '|' | sed '/^[[:space:]]*$/d')

    if [ "${#SELECIONADOS[@]}" -eq 0 ]; then
        yad --warning --title="Nenhum usuário" --center --borders=10 \
            --text="Marque pelo menos um usuário para continuar." \
            --button="Voltar à lista:0" --button="Sair:1" || exit 0
        continue
    fi

    echo "Selecionados: ${SELECIONADOS[*]}"
    confirm_usuarios "${SELECIONADOS[@]}" || continue

    if setup_usuarios "${SELECIONADOS[@]}"; then
        finish
        break
    fi

    yad --error --title="Erro" --center --borders=10 \
        --text="Erro durante a configuração.\n\nDetalhes em: $LOG\ne em /usr/local/seduc/logs/criar_usuarios.log" \
        --button="Tentar novamente:0" --button="Sair:1" || exit 1
done

echo "===== FIM $(date) ====="
